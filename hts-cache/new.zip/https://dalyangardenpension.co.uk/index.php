<!doctype html>
<html>
<head>

<meta http-equiv="content-type" content="text/html; charset=UTF-8" />
<title>Dalyan Garden Pension - Turkey. Hotel with Pool, beautiful Mediterranean beaches, Turtle reserve</title>
<meta name="description" content="" />

<meta name="generator" content="concrete5 - 5.7.5.6" />
<script type="text/javascript">
var CCM_DISPATCHER_FILENAME = '/index.php';var CCM_CID = 1;var CCM_EDIT_MODE = false;var CCM_ARRANGE_MODE = false;var CCM_IMAGE_PATH = "/updates/concrete5.7.5.6/concrete/images";
var CCM_TOOLS_PATH = "/index.php/tools/required";
var CCM_APPLICATION_URL = "https://dalyangardenpension.co.uk";
var CCM_REL = "";

</script>


        <link rel="shortcut icon" href="https://dalyangardenpension.co.uk/application/files/5014/4982/6183/favicon_thumbnail.ico" type="image/x-icon"/>
        <link rel="icon" href="https://dalyangardenpension.co.uk/application/files/5014/4982/6183/favicon_thumbnail.ico" type="image/x-icon"/>
            <link rel="apple-touch-icon" href="https://dalyangardenpension.co.uk/application/files/2514/4982/6185/iphone_thumbnail.png"/>
            <meta name="msapplication-TileImage" content="https://dalyangardenpension.co.uk/application/files/4114/4982/6184/win_thumbnail.png" />
<script type="text/javascript" src="/updates/concrete5.7.5.6/concrete/js/jquery.js"></script>
<link href="/application/files/cache/css/eec81acb566de23502740bd0ff7bd01d097d12d5.css" rel="stylesheet" type="text/css" media="all" data-source="/updates/concrete5.7.5.6/concrete/blocks/autonav/templates/responsive_header_navigation/view.css /updates/concrete5.7.5.6/concrete/css/responsive-slides.css /application/blocks/image_slider/view.css">

<!--
<link rel="stylesheet" type="text/css" href="https://yui.yahooapis.com/3.18.1/build/cssreset/cssreset-min.css">
<link rel="stylesheet" type="text/css" href="https://yui.yahooapis.com/3.18.1/build/cssbase/cssbase-min.css">
-->
<link href='https://fonts.googleapis.com/css?family=Dancing+Script:400,700|Lato:300,300italic,700,700italic|Kalam|Zeyada' rel='stylesheet' type='text/css'>
<link href="/application/themes/dgp/css/dgp.css" rel="stylesheet" type="text/css">
<link href="/application/themes/dgp/css/dd_nav.css" rel="stylesheet" type="text/css">
</head>

<body>
<div id="pw" class="ccm-page page-template-full">



<div id="divHeader" class="wrapper">
<div id="divSiteTitle">
	

    <a href="https://dalyangardenpension.co.uk/"><img src="/application/files/5314/3990/5675/logo_dgp.png" alt="Dalyan Garden Pension" width="475" height="36" class="ccm-image-block img-responsive bID-45"></a>

</div><!-- /#divSiteTitle -->
<div id="divSiteNav">
	

    
<nav class="ccm-responsive-navigation original"><ul><li class=""><a href="https://dalyangardenpension.co.uk/pension" target="_self" class="">The pension</a><ul><li class=""><a href="https://dalyangardenpension.co.uk/pension/rooms" target="_self" class="">Rooms</a></li><li class=""><a href="https://dalyangardenpension.co.uk/pension/pool-garden" target="_self" class="">Pool &amp; garden</a></li><li class=""><a href="https://dalyangardenpension.co.uk/pension/our-hospitality" target="_self" class="">Our hospitality</a></li></ul></li><li class=""><a href="https://dalyangardenpension.co.uk/area" target="_self" class="">The area</a><ul><li class=""><a href="https://dalyangardenpension.co.uk/area/towns-and-markets" target="_self" class="">Towns and markets</a></li><li class=""><a href="https://dalyangardenpension.co.uk/area/rivers-lakes-and-beaches" target="_self" class="">Rivers, lakes and beaches</a></li><li class=""><a href="https://dalyangardenpension.co.uk/area/kaunos-the-tombs-and-historical-sites" target="_self" class="">Kaunos, the tombs and historical sites</a></li><li class=""><a href="https://dalyangardenpension.co.uk/area/nature-and-wildlife" target="_self" class="">Nature and wildlife</a></li></ul></li><li class=""><a href="https://dalyangardenpension.co.uk/plan-a-visit" target="_self" class="">Plan a visit</a><ul><li class=""><a href="https://dalyangardenpension.co.uk/plan-a-visit/room-rates" target="_self" class="">Room rates</a></li><li class=""><a href="https://dalyangardenpension.co.uk/plan-a-visit/how-get-here" target="_self" class="">How to get here</a></li><li class=""><a href="https://dalyangardenpension.co.uk/plan-a-visit/when-come" target="_self" class="">When to come</a></li></ul></li><li class=""><a href="https://dalyangardenpension.co.uk/contact-us" target="_self" class="">Contact us</a><ul><li class=""><a href="https://dalyangardenpension.co.uk/contact-us/booking-enquiry" target="_self" class="">Booking enquiry</a></li><li class=""><a href="https://dalyangardenpension.co.uk/contact-us/find-us" target="_self" class="">Find us</a></li></ul></li><li class=""><a href="http://dalyangardenpension.co.uk/plan-a-visit/room-rates#ext" target="_self" class="">Book direct for best rates</a></li></ul></nav><div class="ccm-responsive-menu-launch"><i></i></div>
</div><!-- /#divSiteNav -->
</div><!-- /#divHeader -->

<div id="divHeaderImage" class="wrapper tallHeader">
	

    <script>
$(document).ready(function(){
    $(function () {
        $("#ccm-image-slider-309").responsiveSlides({
            prevText: "",   // String: Text for the "previous" button
            nextText: "",
                        nav:true
                    });
    });
});
</script>

<div class="ccm-image-slider-container ccm-block-image-slider-arrows" >
    <div class="ccm-image-slider">
        <div class="ccm-image-slider-inner">

                <ul class="rslides" id="ccm-image-slider-309">
                            <li>
                                                <img src="/application/files/3714/4958/9082/home100.jpg" alt="slide" width="1600" height="750">                                <div class="ccm-image-slider-text">
                                                        </div>
                </li>
                            <li>
                                                <img src="/application/files/8914/4958/9002/home101.jpg" alt="slide" width="1600" height="750">                                <div class="ccm-image-slider-text">
                                                        </div>
                </li>
                            <li>
                                                <img src="/application/files/3514/4846/5619/pension2.jpg" alt="slide" width="1600" height="750">                                <div class="ccm-image-slider-text">
                                                        </div>
                </li>
                            <li>
                                                <img src="/application/files/9614/4846/5614/pension1.jpg" alt="slide" width="1600" height="750">                                <div class="ccm-image-slider-text">
                                                        </div>
                </li>
                    </ul>
                </div>

    </div>
</div>

    <!-- <div style="background-image:url(/application/files/4514/4002/8021/header_home.jpg);" class="img"></div> -->
</div><!-- /#divHeaderImage -->

<div id="divContent" class="wrapper">
	<div class="wrapper">

        <div id="divMain" class="wrapper col_x2">
        	

    <h1>Welcome</h1><p><strong>Dalyan Garden Pension</strong> is a small family run hotel set in the rural Arikbasi area of Dalyan. Since opening in 2005 it has featured in many guide books such as Cadogan’s Guide to Turkey, Guide Evasion, Guide Hachette and the Sunflower Guide - Kas to Dalyan. It has also featured in the <a target="_blank" href="https://dalyangardenpension.co.uk/download_file/view/100/1">Sunday Times Travel magazine</a>, the Daily Telegraph Travel Section and an airline <a target="_blank" href="https://dalyangardenpension.co.uk/download_file/view/101/1">in-flight magazine</a>.<br></p><p>The pension has become a firm favourite with many guests who we welcome back year after year. The <a href="https://dalyangardenpension.co.uk/pension/rooms">ten simple rooms</a> set facing a <a href="https://dalyangardenpension.co.uk/pension/pool-garden">seventeen metre pool</a>, shady garden and convivial bar offer comfortable informal accommodation. From the upstairs balcony there are lovely views of the surrounding mountains and farmland. It is the perfect location whether you just to want to unwind - reading in the shade of the garden, sunbathing or cooling off in the pool, or whether you prefer to spend time at <a href="https://dalyangardenpension.co.uk/area/rivers-lakes-and-beaches">the beach</a> or explore the <a href="https://dalyangardenpension.co.uk/area/kaunos-the-tombs-and-historical-sites">surrounding countryside</a>.<br></p>
        </div><!-- /#divMain -->
        <div id="divSidebar" class="wrapper col_x1">
        	

    <p style="text-align: center;"><img src="/application/files/3215/2815/6286/ta-hall-of-fame.png" alt="ta-hall-of-fame.png" width="156" height="138" id="image-marker">
</p>


    
<div id="HTMLBlock325" class="HTMLBlock">
<div style="margin: 20px auto 0;width:160px;" id="TA_cdsratingsonlynarrow418" class="TA_cdsratingsonlynarrow"><ul id="mZv7KnmDzLu" class="TA_links G1b3ei"><li id="D2l1IlWmq" class="vMe5LszegA"><a target="_blank" href="https://www.tripadvisor.co.uk/"><img src="https://www.tripadvisor.co.uk/img/cdsi/img2/branding/tripadvisor_logo_transp_340x80-18034-2.png" alt="TripAdvisor"/></a></li></ul></div><script async src="https://www.jscache.com/wejs?wtype=cdsratingsonlynarrow&uniq=418&locationId=608098&lang=en_UK&border=true&display_version=2"></script></div>
        </div><!-- /#divSidebar -->
        <div id="divLinks1" class="wrapper col_x1">
        	

        <div class="ccm-custom-style-container ccm-custom-style-maincolumn1-198 ornament_top" >
    <p data-redactor-inserted-image="true"><img src="/application/files/1514/4008/0119/times_travel.jpg" width="89" height="119" style="float: left; margin: 0px 10px 10px 0px;"></p><p>“A garden oasis in the heart of the Dalyan delta – this pensione is a delight”<br><span class="small">Sunday Times Travel, July 2010<br><a target="_blank" href="https://dalyangardenpension.co.uk/download_file/view/100/1">Click to read</a></span>  </p>
    </div>
        </div><!-- /#divlinks1 -->
        <div id="divLinks2" class="wrapper col_x1">
        	

        <div class="ccm-custom-style-container ccm-custom-style-maincolumn2-195 ornament_top" >
    <p data-redactor-inserted-image="true"><img src="/application/files/7714/4008/0120/altitude.jpg" width="100" height="128" style="float: left; margin: 0px 10px 10px 0px;"></p><p>Featured in XL in-flight magazine, summer 2007<br><span class="small"><a target="_blank" href="https://dalyangardenpension.co.uk/download_file/view/101/1">Click to read</a> </span></p>
    </div>
        </div><!-- /#divlinks2 -->
    </div><!-- /.wrapper -->
</div><!-- /#divContent -->

<div id="divFooter" class="wrapper">
    <div id="divFooterContent" class="wrapper">
        

        <div class="ccm-custom-style-container ccm-custom-style-footercontent-112 testimonial" >
    <p>Even better than web-site. Wonderful place to ‘chill’. Ercan and staff are great.</p><p>Neil &amp; Ruth Avison<br></p>
    </div>
    </div><!-- /#divFooterContent -->
    <div id="divLegals" class="wrapper">
        

    <p data-redactor-inserted-image="true"><img src="/application/files/2014/4967/9015/wifi.png" width="57" height="50" style="float: right; margin: 0px 0px 10px 10px;"></p><p>All images © 2019 Dalyan Garden Pension. All rights reserved. <a href="https://dalyangardenpension.co.uk/privacy-policy">Privacy policy</a>  </p>
    </div><!-- /#divLegals -->
</div><!-- /#divFooter -->

<script type="text/javascript" src="//downloads.mailchimp.com/js/signup-forms/popup/unique-methods/embed.js" data-dojo-config="usePlainJson: true, isDebug: false"></script><script type="text/javascript">window.dojoRequire(["mojo/signup-forms/Loader"], function(L) { L.start({"baseUrl":"mc.us3.list-manage.com","uuid":"d2b7d9a948c658d9e951729eb","lid":"b9d85a5040","uniqueMethods":true}) })</script>


</div><!-- /#divBody -->




<script src="https://cdnjs.cloudflare.com/ajax/libs/gsap/latest/TweenMax.min.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/ScrollMagic.js"></script>
<script src="//cdnjs.cloudflare.com/ajax/libs/ScrollMagic/2.0.5/plugins/animation.gsap.js"></script>
<script src="/application/themes/dgp/js/dgp.js" type="text/javascript"></script>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript">
try {
var pageTracker = _gat._getTracker("UA-1711162-1");
pageTracker._trackPageview();
} catch(err) {}</script><script type="text/javascript" src="/application/files/cache/js/b6e1d1b39abc0d3114fe505eea57efbd13fee4ae.js" data-source="/updates/concrete5.7.5.6/concrete/blocks/image/js/hover.js /updates/concrete5.7.5.6/concrete/blocks/autonav/templates/responsive_header_navigation/view.js /updates/concrete5.7.5.6/concrete/js/responsive-slides.js /application/blocks/image_slider/view.js"></script>
</body>
</html>
